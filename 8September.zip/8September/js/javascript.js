// Create a program to swap two numbers.
let a = 40;
let b = 30;
let c = a;
a = b;
b = c;
console.log('Swap a = ', a);
console.log('Swap b = ', b);

// Find the area of a rectangle (length × width).
let length = 100;
let width = 80;
let rectangle = length * width;
console.log('Rectangle value is = ',rectangle);

// Convert temperature from Celsius to Fahrenheit.
let Celsius = 40;
let Fahrenheit = (Celsius * 9/5 ) +32; 
console.log('Fahrenheit = ', Fahrenheit);

// Calculate simple interest (P × R × T / 100).
let p = 1600;
let r = 4;
let t = 4;
let simpleInterest = (p * r * t /100);
console.log('Simple Interest is = ',simpleInterest);

// Check if a number is even or odd (only using % operator, without if yet — just output the remainder).
// let number = 16;
// let result = number % 2 == 0 ? number % 2 == 1;
// console.log(result);

// Concatenate first name and last name into a full name.
let firstName = "Parag";
let lastName = "Ahir";
let fullName = firstName + " " + lastName;
console.log('Fullname = ',fullName);


